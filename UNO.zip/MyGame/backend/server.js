"use strict";
exports.__esModule = true;
var Socket = require("socket.io").Socket;
var express = require("express");
var app = express();
var http = require("http");
var Server = require('socket.io').Server;
var cors = require('cors');
var HomePage_1 = require("./HomePage");
var GameEvents_1 = require("./GameEvents");
var GameEvents_2 = require("./GameEvents");
var GameEvents_3 = require("./GameEvents");
var Player = /** @class */ (function () {
    function Player(socket, name, hand) {
        this.socket = [];
        this.name = '';
        this.hand = [];
        this.socket = socket;
        this.name = name;
        this.hand = hand;
    }
    return Player;
}());
var GameSession = /** @class */ (function () {
    function GameSession(players, deck, discardPile, currentPlayer, direction, chosencolor, winner, gameOver) {
        this.deck = [];
        this.discardPile = [];
        this.currentPlayer = 0;
        this.direction = 0;
        this.players = [];
        this.chosencolor = '';
        this.winner = '';
        this.gameOver = false;
        this.players = players;
        this.deck = deck;
        this.discardPile = discardPile;
        this.currentPlayer = currentPlayer;
        this.direction = direction;
        this.chosencolor = chosencolor;
        this.winner = '';
        this.gameOver = gameOver;
    }
    return GameSession;
}());
var player1 = new Player([], '', []);
var player2 = new Player([], '', []);
var player3 = new Player([], '', []);
var player4 = new Player([], '', []);
var players = [player1, player2, player3, player4];
var GameSession1 = new GameSession(players, [], [], 0, 0, '', '', false);
///// variables
var sockets = [];
var socket_id = [];
// const HomeEvents = require('./HomePage')
app.use(cors());
var server = http.createServer(app);
var io = new Server(server, { cors: {
        origin: "http://localhost:3001",
        methods: ["GET", "POST"]
    }
});
server.listen(3001, function () {
    console.log("SERVER IS LISTENING ON PORT 3001");
});
//////////// HOME VARIABLES
// const sockets: Socket[] = [];
// const socket_id: string[] = [];
// const num_players = 4;
// const username: string[] = []
// let count:number = 0;
// let connected:number = 0;
io.on("connection", function (socket) {
    (0, HomePage_1["default"])(socket, io, sockets, socket_id, players);
    // initializeGame
    (0, GameEvents_1.game_start)(socket, io, players, GameSession1, sockets);
    // A CARD IS PLAYED 
    for (var i = 0; i < 4; i++) {
        io.to(players[i].socket.id).emit('username', players[i].hand);
    }
    socket.on("play-card", function (card) {
        var flag = false;
        flag = (0, GameEvents_2.playCard)(io, players, card[0], GameSession1, card[1], socket);
        if (flag === false) {
            io.to(GameSession1.players[GameSession1.currentPlayer].id).emit('card-unplayable', 'Card is unplayable');
            flag = (0, GameEvents_2.playCard)(io, players, card[0], GameSession1, card[1], socket);
        }
        if (flag === true) {
            var flag_uno = (0, GameEvents_3.checkForUno)(players, GameSession1, io, socket);
            console.log("current player ", GameSession1.players[GameSession1.currentPlayer].name);
            var string = "It's " + GameSession1.players[GameSession1.currentPlayer].name + " turn";
            if (flag_uno) {
                var string_winner = GameSession1.players[GameSession1.currentPlayer].name + " has won the game";
                io.emit('winner', string_winner);
            }
            else {
                //io.to(GameSession1.players[GameSession1.currentPlayer].id).emit('turn', string);
                io.emit('turn', string);
            }
        }
        //     io.to(GameSession1.players[index].socket.id).emit('hand', GameSession1.players[index].hand);
        //     io.to(GameSession1.players[GameSession1.currentPlayer].socket.id).emit('valid-turn', "Valid Turn");
        // }
        // else{
        //     io.to(GameSession1.players[index].sokcet.id).emit('card-unplayable','card-unplayable'); 
        // }
    });
    socket.on("pass", function () {
        GameSession1.players[GameSession1.currentPlayer].hand.push(GameSession1.deck.pop());
        var flag_uno = (0, GameEvents_3.checkForUno)(players, GameSession1, io, socket);
        console.log("current player ", GameSession1.players[GameSession1.currentPlayer].name);
        var string = "It's " + GameSession1.players[GameSession1.currentPlayer].name + " turn";
        if (flag_uno) {
            var string_winner = GameSession1.players[GameSession1.currentPlayer].name + " has won the game";
            io.emit('winner', string_winner);
        }
        else {
            //io.to(GameSession1.players[GameSession1.currentPlayer].id).emit('turn', string);
            io.emit('turn', string);
        }
    });
    // /// HOME EVENTS 
    //     connected = connected+1     
    //     if (sockets.length <= 2)
    //     {
    //      socket.on("username",(myData)=>{
    //         console.log('Player joined: ', myData);
    //         username.push(myData)
    //         sockets.push(socket);
    //         socket_id.push(socket.id);
    //         console.log(socket_id)   
    //         count = count+1;
    //         console.log("user connected with a socket id", socket.id)
    //         io.emit('player-joined', count);
    //         io.emit('username-joined', username);
    //     })
    //     }
    //     else if(sockets.length === num_players-1) {
    //             socket.on("username",(myData)=>{
    //             console.log('Player joined: ', myData);
    //             username.push(myData)
    //             socket_id.push(socket.id);
    //             sockets.push(socket);
    //             console.log(socket_id)        
    //             console.log("user connected with a socket id", socket.id)
    //             io.emit('start-game');   
    //             io.emit('username-joined', username);
    //             console.log('Starting the game... hahaha');        
    //             // const message = 'Hello, there!';
    //             // io.to(socket_id[0]).emit('private-message', message);
    //         })
    //     }
    //     else if(connected>=4)
    //     {
    //         socket.disconnect()
    //     }      
});
//////// GAME EVENTS 
