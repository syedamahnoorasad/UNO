export function game_start(socket, io, players, GameSession, sockets)
{
  
    //   useEffect(() => {
        socket.on('signal-to-begin',() =>
        {
            io.emit("proceed-to-game","")
            console.log('sending message to all clients to load game')
            console.log(socket.id)
            initializeGame(players,GameSession)
            // console.log(GameSession)
            // console.log(players[0].hand)
            // console.log(GameSession.deck.length)
    //         return () => socket.off("proceed-to-game","");
          for( let x = 0; x<4; x++)
          { 
            console.log("sending hand to ", GameSession.players[x].socket.id)
            io.to(GameSession.players[x].socket.id).emit('hand', GameSession.players[x].hand);
            io.to(GameSession.players[x].socket.id).emit('discardPile', GameSession.discardPile[GameSession.discardPile.length - 1]);
            // console.log('discardPile', GameSession.discardPile[GameSession.discardPile.length - 1])
            io.to(GameSession.players[x].socket.id).emit('deckTop', GameSession.deck[GameSession.deck.length - 1]);
            io.to(GameSession.players[x].socket.id).emit('yourName', [GameSession.players[x].name]);
            let otherPlayers:string[] = []
            for( let i = 0; i<4; i++)
            {
              if( GameSession.players[i].name!== GameSession.players[x].name)
              {
                otherPlayers.push(GameSession.players[i].name)
              }
            }
            io.to(GameSession.players[x].socket.id).emit('otherPlayerNames', otherPlayers);

            io.to(players[x].socket.id).emit('username', players[x].name);
          }
          let string_x:string = "Take your turn, " + players[0].name + "!";
          io.emit('first-person', string_x);
        })


        }

// GameSession.deck.push(`card num-${number} ${color}`);
// if (number !== 0) {
//     GameSession.deck.push(`card num-${number} ${color}`);
// }
// }
// for (const action of actions) {
//     GameSession.deck.push(`card ${action} ${color}`);
//     GameSession.deck.push(`card ${action} ${color}`);
// }
// GameSession.deck.push(`card ${wilds[1]}`);

export function initializeGame(players, GameSession) {

    GameSession.deck = [];
    const colors:string[] = ["red", "blue", "green", "yellow"];
    const numbers: number[] = Array.from({ length: 10 }, (_, i) => i);
    const actions:string[]  = ["S", "R", "D2"];
    const wilds:string[]  = ["wild", "D4"];
    for (const col of colors) {
        for (const number of numbers) {
            GameSession.deck.push({value: (String(number)), color: col});
        if (number !== 0) {
            GameSession.deck.push({value: (String(number)), color: col});
        }
        }
        for (const action of actions) {
            GameSession.deck.push({value: action, color: col});
            GameSession.deck.push({value: action, color: col});
        }
        GameSession.deck.push({value:  wilds[1], color: wilds[0]});
    }
    for (let i = GameSession.deck.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [GameSession.deck[i], GameSession.deck[j]] = [GameSession.deck[j], GameSession.deck[i]];
    }


    // Deal 7 cards to each player
    for (const player of players) {
        player.hand = Array.from({length: 7}, () => GameSession.deck.pop());
    }

    GameSession.discardPile.push(GameSession.deck.pop());

        GameSession.currentPlayer= 0
        GameSession.direction =  1
        GameSession.players = players
}


//// draw 2 card wala will do this and also class the draw 2 wal:a function 
export function playCard(io, players, cardIndex, GameSession, color, socket):boolean {

    const card = GameSession.players[GameSession.currentPlayer].hand[cardIndex];
    const topCard = GameSession.discardPile[GameSession.discardPile.length - 1];

    if (topCard.color === 'wild' && topCard.value=== 'D4' && GameSession.discardPile.length === 1){
      for (let i = 0; i < 4; i++) 
      {
        GameSession.players[GameSession.currentPlayer].hand.push(GameSession.deck[GameSession.deck.length - 1]);
      }
        return true;

    } 

    if (card.color === 'wild' && card.value=== 'D4'){
      
      let flag: boolean = playWildDraw4(players, GameSession, color, topCard)
      if(!flag){
        return false;
      }

    }    
    if (!canPlayCard(card, topCard) && card.value !== "draw-4") {
      return false; 
    }

    players[GameSession.currentPlayer].hand.splice(cardIndex, 1);
    GameSession.discardPile.push(card);

    if(card.value === "D2")
    {
        drawTwo(players, GameSession)
    }
    if(card.value ===  "R")
    {
        reverseDirection(GameSession)
    }
    if(card.value === "S")
    {
        skipTurn(GameSession)    
    }

    return true; 
}

export function pass(GameSession) {
  // Move to the next player
  const currentPlayerIndex = GameSession.currentPlayer;
  GameSession.players[currentPlayerIndex].hand.push(GameSession.deck.pop());
  const nextPlayerIndex = getNextPlayerIndex(currentPlayerIndex, GameSession.direction, GameSession.players.length);
  GameSession.currentPlayer = nextPlayerIndex;
}

  function playWildDraw4(players, GameSession, chosenColor, topCard): boolean {
    const hasPlayableCard = players.hand.some(card => canPlayCard(card, topCard));
    if (hasPlayableCard) {
      return false; 
    }
  
    let nextPlayerIndex = getNextPlayerIndex(GameSession.currentPlayer, GameSession.direction, GameSession.players.length);
    for (let i = 0; i < 4; i++) 
    {
      GameSession.players[nextPlayerIndex].hand.push(GameSession.deck[GameSession.deck.length - 1]);
    }
  
    GameSession.chosencolor = chosenColor;
    
    return true; 
  }
  


function canPlayCard(card, topCard): boolean {
    
    if (card.color === topCard.color || card.value === topCard.value) {
      return true;
    }
    
    return false;
  }
  
export function reverseDirection(GameSession) {
    GameSession.direction * -1;
}


export function skipTurn(GameSession){
    const currentPlayerIndex = GameSession.currentPlayer;
    const playerCount = GameSession.players.length;
    const direction = GameSession.direction;
    
    let nextPlayerIndex = (currentPlayerIndex + direction + playerCount) % playerCount;
    GameSession.currentPlayer = nextPlayerIndex;
}


export function drawTwo(players, GameSession) {
    const currentPlayerIndex = GameSession.currentPlayer;
    const nextPlayerIndex = getNextPlayerIndex(currentPlayerIndex, GameSession.direction, GameSession.players.length);
    
    for (let i = 0; i < 2; i++) {
      const card = GameSession.deck.pop();
      players[nextPlayerIndex].hand.push(card);
    }
    
  }


function getNextPlayerIndex(currentPlayerIndex: number, direction: number, numPlayers: number): number {
    let nextPlayerIndex = currentPlayerIndex + direction;
    if (nextPlayerIndex < 0) {
      nextPlayerIndex = numPlayers - 1;
    } else if (nextPlayerIndex >= numPlayers) {
      nextPlayerIndex = 0;
    }
    return nextPlayerIndex;
  }

  ///////check for UNO after playcard 
  export function checkForUno(players, GameSession, io, socket): boolean {
    const currentPlayer = GameSession.currentPlayer
    const numCards = GameSession.players[GameSession.currentPlayer].hand.length;
    if (numCards === 1 && !currentPlayer.calledUno) {
      io.to(players[currentPlayer].socket.id).emit('message', 'Don\'t forget to say "Uno"!','');
          GameSession.winner = GameSession.players[currentPlayer].name;
          return true;
    }   
     GameSession.currentPlayer = getNextPlayerIndex(GameSession.currentPlayer, GameSession.direction, GameSession.players.length);

    return false;
  }

  export function checkDeck(GameSession, io, socket): boolean {
    if (GameSession.deck.length === 0) {
      GameSession.winner = GameSession.players[GameSession.currentPlayer].name;
      return true;
    }
    return false;
  }


  // export function endGame(GameSession) {
  //   for (let i = 0; i < GameSession.players.length; i++) {
  //     if (GameSession.players[i].hand.length === 0) {
  //       GameSession.winner = GameSession.players[i].name;
  //       GameSession.gameOver = true;
  //       return true;
  //     }
  //   }
    
  //   return false; 
  // }
  
  

  
  

