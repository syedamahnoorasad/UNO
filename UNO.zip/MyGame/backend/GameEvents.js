"use strict";
exports.__esModule = true;
exports.checkDeck = exports.checkForUno = exports.drawTwo = exports.skipTurn = exports.reverseDirection = exports.pass = exports.playCard = exports.initializeGame = exports.game_start = void 0;
function game_start(socket, io, players, GameSession, sockets) {
    //   useEffect(() => {
    socket.on('signal-to-begin', function () {
        io.emit("proceed-to-game", "");
        console.log('sending message to all clients to load game');
        console.log(socket.id);
        initializeGame(players, GameSession);
        // console.log(GameSession)
        // console.log(players[0].hand)
        // console.log(GameSession.deck.length)
        //         return () => socket.off("proceed-to-game","");
        for (var x = 0; x < 4; x++) {
            console.log("sending hand to ", GameSession.players[x].socket.id);
            io.to(GameSession.players[x].socket.id).emit('hand', GameSession.players[x].hand);
            io.to(GameSession.players[x].socket.id).emit('discardPile', GameSession.discardPile[GameSession.discardPile.length - 1]);
            // console.log('discardPile', GameSession.discardPile[GameSession.discardPile.length - 1])
            io.to(GameSession.players[x].socket.id).emit('deckTop', GameSession.deck[GameSession.deck.length - 1]);
            io.to(GameSession.players[x].socket.id).emit('yourName', [GameSession.players[x].name]);
            var otherPlayers = [];
            for (var i = 0; i < 4; i++) {
                if (GameSession.players[i].name !== GameSession.players[x].name) {
                    otherPlayers.push(GameSession.players[i].name);
                }
            }
            io.to(GameSession.players[x].socket.id).emit('otherPlayerNames', otherPlayers);
            io.to(players[x].socket.id).emit('username', players[x].name);
        }
        var string_x = "Take your turn, " + players[0].name + "!";
        io.to(players[0].socket.id).emit('first-person', string_x);
    });
}
exports.game_start = game_start;
// GameSession.deck.push(`card num-${number} ${color}`);
// if (number !== 0) {
//     GameSession.deck.push(`card num-${number} ${color}`);
// }
// }
// for (const action of actions) {
//     GameSession.deck.push(`card ${action} ${color}`);
//     GameSession.deck.push(`card ${action} ${color}`);
// }
// GameSession.deck.push(`card ${wilds[1]}`);
function initializeGame(players, GameSession) {
    var _a;
    GameSession.deck = [];
    var colors = ["red", "blue", "green", "yellow"];
    var numbers = Array.from({ length: 10 }, function (_, i) { return i; });
    var actions = ["S", "R", "D2"];
    var wilds = ["wild", "D4"];
    for (var _i = 0, colors_1 = colors; _i < colors_1.length; _i++) {
        var col = colors_1[_i];
        for (var _b = 0, numbers_1 = numbers; _b < numbers_1.length; _b++) {
            var number = numbers_1[_b];
            GameSession.deck.push({ value: (String(number)), color: col });
            if (number !== 0) {
                GameSession.deck.push({ value: (String(number)), color: col });
            }
        }
        for (var _c = 0, actions_1 = actions; _c < actions_1.length; _c++) {
            var action = actions_1[_c];
            GameSession.deck.push({ value: action, color: col });
            GameSession.deck.push({ value: action, color: col });
        }
        GameSession.deck.push({ value: wilds[1], color: wilds[0] });
    }
    for (var i = GameSession.deck.length - 1; i > 0; i--) {
        var j = Math.floor(Math.random() * (i + 1));
        _a = [GameSession.deck[j], GameSession.deck[i]], GameSession.deck[i] = _a[0], GameSession.deck[j] = _a[1];
    }
    // Deal 7 cards to each player
    for (var _d = 0, players_1 = players; _d < players_1.length; _d++) {
        var player = players_1[_d];
        player.hand = Array.from({ length: 7 }, function () { return GameSession.deck.pop(); });
    }
    GameSession.discardPile.push(GameSession.deck.pop());
    GameSession.currentPlayer = 0;
    GameSession.direction = 1;
    GameSession.players = players;
}
exports.initializeGame = initializeGame;
//// draw 2 card wala will do this and also class the draw 2 wal:a function 
function playCard(io, players, cardIndex, GameSession, color, socket) {
    var card = GameSession.players[GameSession.currentPlayer].hand[cardIndex];
    var topCard = GameSession.discardPile[GameSession.discardPile.length - 1];
    if (topCard.color === 'wild' && topCard.value === 'D4' && GameSession.discardPile.length === 1) {
        for (var i = 0; i < 4; i++) {
            GameSession.players[GameSession.currentPlayer].hand.push(GameSession.deck[GameSession.deck.length - 1]);
        }
        return true;
    }
    if (card.color === 'wild' && card.value === 'D4') {
        var flag = playWildDraw4(players, GameSession, color, topCard);
        if (!flag) {
            return false;
        }
    }
    if (!canPlayCard(card, topCard) && card.value !== "draw-4") {
        return false;
    }
    players[GameSession.currentPlayer].hand.splice(cardIndex, 1);
    GameSession.discardPile.push(card);
    if (card.value === "D2") {
        drawTwo(players, GameSession);
    }
    if (card.value === "R") {
        reverseDirection(GameSession);
    }
    if (card.value === "S") {
        skipTurn(GameSession);
    }
    return true;
}
exports.playCard = playCard;
function pass(GameSession) {
    // Move to the next player
    var currentPlayerIndex = GameSession.currentPlayer;
    GameSession.players[currentPlayerIndex].hand.push(GameSession.deck.pop());
    var nextPlayerIndex = getNextPlayerIndex(currentPlayerIndex, GameSession.direction, GameSession.players.length);
    GameSession.currentPlayer = nextPlayerIndex;
}
exports.pass = pass;
function playWildDraw4(players, GameSession, chosenColor, topCard) {
    var hasPlayableCard = players.hand.some(function (card) { return canPlayCard(card, topCard); });
    if (hasPlayableCard) {
        return false;
    }
    var nextPlayerIndex = getNextPlayerIndex(GameSession.currentPlayer, GameSession.direction, GameSession.players.length);
    for (var i = 0; i < 4; i++) {
        GameSession.players[nextPlayerIndex].hand.push(GameSession.deck[GameSession.deck.length - 1]);
    }
    GameSession.chosencolor = chosenColor;
    return true;
}
function canPlayCard(card, topCard) {
    if (card.color === topCard.color || card.value === topCard.value) {
        return true;
    }
    return false;
}
function reverseDirection(GameSession) {
    GameSession.direction * -1;
}
exports.reverseDirection = reverseDirection;
function skipTurn(GameSession) {
    var currentPlayerIndex = GameSession.currentPlayer;
    var playerCount = GameSession.players.length;
    var direction = GameSession.direction;
    var nextPlayerIndex = (currentPlayerIndex + direction + playerCount) % playerCount;
    GameSession.currentPlayer = nextPlayerIndex;
}
exports.skipTurn = skipTurn;
function drawTwo(players, GameSession) {
    var currentPlayerIndex = GameSession.currentPlayer;
    var nextPlayerIndex = getNextPlayerIndex(currentPlayerIndex, GameSession.direction, GameSession.players.length);
    for (var i = 0; i < 2; i++) {
        var card = GameSession.deck.pop();
        players[nextPlayerIndex].hand.push(card);
    }
}
exports.drawTwo = drawTwo;
function getNextPlayerIndex(currentPlayerIndex, direction, numPlayers) {
    var nextPlayerIndex = currentPlayerIndex + direction;
    if (nextPlayerIndex < 0) {
        nextPlayerIndex = numPlayers - 1;
    }
    else if (nextPlayerIndex >= numPlayers) {
        nextPlayerIndex = 0;
    }
    return nextPlayerIndex;
}
///////check for UNO after playcard 
function checkForUno(players, GameSession, io, socket) {
    var currentPlayer = GameSession.currentPlayer;
    var numCards = GameSession.players[GameSession.currentPlayer].hand.length;
    if (numCards === 1 && !currentPlayer.calledUno) {
        io.to(players[currentPlayer].socket.id).emit('message', 'Don\'t forget to say "Uno"!', '');
        GameSession.winner = GameSession.players[currentPlayer].name;
        return true;
    }
    GameSession.currentPlayer = getNextPlayerIndex(GameSession.currentPlayer, GameSession.direction, GameSession.players.length);
    return false;
}
exports.checkForUno = checkForUno;
function checkDeck(GameSession, io, socket) {
    if (GameSession.deck.length === 0) {
        GameSession.winner = GameSession.players[GameSession.currentPlayer].name;
        return true;
    }
    return false;
}
exports.checkDeck = checkDeck;
// export function endGame(GameSession) {
//   for (let i = 0; i < GameSession.players.length; i++) {
//     if (GameSession.players[i].hand.length === 0) {
//       GameSession.winner = GameSession.players[i].name;
//       GameSession.gameOver = true;
//       return true;
//     }
//   }
//   return false; 
// }
