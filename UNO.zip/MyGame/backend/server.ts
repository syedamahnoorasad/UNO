const { Socket } = require( "socket.io");
const express = require("express");
const app = express();
const http = require("http");
const {Server} = require('socket.io')
const cors = require('cors')
import home from './HomePage'
import { game_start } from './GameEvents'
import { playCard } from './GameEvents'
import { checkForUno } from './GameEvents'
import { pass } from './GameEvents'


class Player {
    socket: Socket = []
    name: string = ''
    hand: string[] = []
    constructor(socket: Socket, name: string, hand: string[]) {
        this.socket = socket;
        this.name = name;
        this.hand = hand;
    }
}

class GameSession {
    deck: string[] = []
    discardPile: string[] = []
    currentPlayer: number = 0
    direction: number = 0
    players: Socket[] = []
    chosencolor: string = ''
    winner:string = ''
    gameOver:boolean = false
    constructor(players: Socket[], deck:string[], discardPile:string[], currentPlayer:number, direction:number, chosencolor: string, winner:string, gameOver:boolean) {
        this.players = players;
        this.deck = deck;
        this.discardPile = discardPile;
        this.currentPlayer = currentPlayer;
        this.direction = direction;
        this.chosencolor = chosencolor;
        this.winner ='';
        this.gameOver = gameOver;
    }
}
 

const player1 = new Player([], '', []);
const player2 = new Player([], '', []);
const player3 = new Player([], '', []);
const player4 = new Player([], '', []);

const players: Player[] = [player1, player2, player3, player4];
const GameSession1 = new GameSession(players, [], [], 0, 0, '', '', false);


///// variables
const sockets: Socket[] = [];
const socket_id: string[] = [];


// const HomeEvents = require('./HomePage')

app.use(cors())
const server = http.createServer(app)
const io = new Server(
    server,{cors:{
        origin:"http://localhost:3001",
        methods: ["GET", "POST"]
    },
})

server.listen(3001, ()=>{
    console.log("SERVER IS LISTENING ON PORT 3001")
})

//////////// HOME VARIABLES
// const sockets: Socket[] = [];
// const socket_id: string[] = [];
// const num_players = 4;
// const username: string[] = []
// let count:number = 0;
// let connected:number = 0;




io.on("connection",(socket)=>{
    home(socket, io, sockets, socket_id, players)    
    
    // initializeGame
    game_start(socket, io, players, GameSession1, sockets)
    // A CARD IS PLAYED 
    for(let i=0; i<4; i++)
    {
        io.to(players[i].socket.id).emit('username', players[i].hand);
    }

    socket.on("play-card", (card)=>{
        let flag: boolean = false
        flag = playCard(io, players, card[0], GameSession1, card[1], socket)
        if(flag === false)
        {
            io.to(GameSession1.players[GameSession1.currentPlayer].id).emit('card-unplayable', 'Card is unplayable')
            flag = playCard(io, players, card[0], GameSession1, card[1], socket)
        }
        if (flag === true)
        {
            let flag_uno: boolean = checkForUno(players, GameSession1, io, socket)
            console.log("current player ",GameSession1.players[GameSession1.currentPlayer].name)
            let string = "It's "+GameSession1.players[GameSession1.currentPlayer].name+ " turn"
            if(flag_uno)
            {
                let string_winner:string = GameSession1.players[GameSession1.currentPlayer].name + " has won the game"
                io.emit('winner', string_winner);                
            }
            else{
                //io.to(GameSession1.players[GameSession1.currentPlayer].id).emit('turn', string);
                io.emit('turn', string);

            }

        }
        //     io.to(GameSession1.players[index].socket.id).emit('hand', GameSession1.players[index].hand);
        //     io.to(GameSession1.players[GameSession1.currentPlayer].socket.id).emit('valid-turn', "Valid Turn");
              
        // }
        // else{
        //     io.to(GameSession1.players[index].sokcet.id).emit('card-unplayable','card-unplayable'); 
        // }
    })

    socket.on("pass", ()=>{
        GameSession1.players[GameSession1.currentPlayer].hand.push(GameSession1.deck.pop())
        let flag_uno: boolean = checkForUno(players, GameSession1, io, socket)
        console.log("current player ",GameSession1.players[GameSession1.currentPlayer].name)
        let string = "It's "+GameSession1.players[GameSession1.currentPlayer].name+ " turn"
        if(flag_uno)
        {
            let string_winner:string = GameSession1.players[GameSession1.currentPlayer].name + " has won the game"
            io.emit('winner', string_winner);                
        }
        else{
            //io.to(GameSession1.players[GameSession1.currentPlayer].id).emit('turn', string);
            io.emit('turn', string);

        }
    })   



// /// HOME EVENTS 
//     connected = connected+1     

//     if (sockets.length <= 2)
//     {
//      socket.on("username",(myData)=>{
//         console.log('Player joined: ', myData);
//         username.push(myData)
//         sockets.push(socket);
//         socket_id.push(socket.id);
//         console.log(socket_id)   
//         count = count+1;
//         console.log("user connected with a socket id", socket.id)
//         io.emit('player-joined', count);
//         io.emit('username-joined', username);
//     })
//     }
//     else if(sockets.length === num_players-1) {
//             socket.on("username",(myData)=>{
//             console.log('Player joined: ', myData);
//             username.push(myData)
//             socket_id.push(socket.id);
//             sockets.push(socket);
//             console.log(socket_id)        
//             console.log("user connected with a socket id", socket.id)
//             io.emit('start-game');   
//             io.emit('username-joined', username);
     
//             console.log('Starting the game... hahaha');        
//             // const message = 'Hello, there!';
//             // io.to(socket_id[0]).emit('private-message', message);
//         })


//     }
//     else if(connected>=4)
//     {
//         socket.disconnect()
//     }      
            

})
//////// GAME EVENTS 



   


