import { Socket } from "socket.io-client" 
import React, { useEffect } from 'react';
import { useState } from 'react';
import { DefaultEventsMap } from "socket.io/dist/typed-events"
import './Home.css'
import { Navigate, useNavigate } from "react-router-dom";

//create an interface for the props that you want to pass to this component
interface HomePageProps {
    socket: Socket<DefaultEventsMap, DefaultEventsMap> 
}


function HomePage({socket}:HomePageProps){

    //click handler            
    const [gameStarted, setGameStarted] = useState(false);
    const [join, joined] = useState(true);
    const [username, setUsername] = useState(''); // state to store the value of the username input field
    const [isInputFilled, setIsInputFilled] = useState(false);
    const [playerCount, setPlayerCount] = useState(0);
    const [usernameList, usernameListSet] = useState('');
    const navigate = useNavigate();

    

    const handleClick = (socket: Socket) => {
        console.log('Socket ID:', socket.id);
        joined(false)
        socket.emit('username', username);
        

    };

    const handleUsernameChange = (event: React.ChangeEvent<HTMLInputElement>) => {
      setUsername(event.target.value);
      setIsInputFilled(event.target.value !== "");
    };

    useEffect(() => {

      console.log("Mounting the Home.tsx component...")

      socket.on('player-joined', (count:number) => {
          console.log('Player', count, 'Joined');
          setPlayerCount(count);
      });

      socket.on('start-game', () => {
        // console.log('Player 4 Joined');            
        console.log('Starting the game... ddfdsf');
        setGameStarted(true);
        joined(false);            
        socket.emit('signal-to-begin','')
      });

      socket.on('redirect-all', () => {
        console.log('redirecting all players to game page')
        navigate('/game')

      });

      socket.on('username-joined', (username:string[]) => {
        console.log(username, 'have joined');
        const string = JSON.stringify(username);
        usernameListSet(string);
      });

      socket.on('username-joined', (username:string[]) => {
        console.log(username, 'have joined');
        const string = JSON.stringify(username);
        usernameListSet(string);
      });

      // return () => {
        
      // }

    }, []);

    // useEffect(() => {
    //   socket.on('username-joined', (username:string[]) => {
    //       console.log(username, 'have joined');
    //       const string = JSON.stringify(username);
    //       usernameListSet(string);
    //   });
    // }, [socket]);

    // socket.on('private-message', (message:string) => {
    //   console.log('Received a private message:', message);
    // });

    // useEffect(() => {
    //     socket.on('start-game', () => {
    //         // console.log('Player 4 Joined');            
    //         console.log('Starting the game... ddfdsf');
    //         setGameStarted(true);
    //         joined(false);            
    //         socket.emit('signal-to-begin','')
    //         return () => socket.off('start-game');

    //     });
    // }, [socket]);

  //   useEffect(() => {
  //     socket.on('redirect-all', () => {
  //         navigate('/game')
  //     });
  // }, [socket]);



    return(
        <>
          <div className="sampleHomePage">
            {gameStarted ? (
              <>
              <h1 className="gameStarted" text-color="white">Let the game begin!</h1>
              <p className="gameStarted" text-color="white"> {usernameList} are in the lobby!</p>
              </>
            ) : 
            join ? 
            (
              <>
                <p className="sampleTitle">Enter your username</p>
                <div className="sampleMessage">
                <input
                placeholder="Username"
                value={username} 
                onChange={handleUsernameChange}
                />
                  <button onClick={() => handleClick(socket)}  disabled={!isInputFilled}>
                    ENTER
                  </button>
                </div>
              </>
            ) : 
            !join ? (<p className="gameStarted" text-color="white">{playerCount} player(s) joined.... Waiting for more players. {usernameList} in lobby.</p>
             ) : null 
            }            
          </div>
        </>
      );

}


export default HomePage
