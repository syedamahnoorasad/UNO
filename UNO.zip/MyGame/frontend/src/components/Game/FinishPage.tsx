import { Socket } from "socket.io-client" 
import React, { useEffect } from 'react';
import { useState } from 'react';
import { DefaultEventsMap } from "socket.io/dist/typed-events"
import { Navigate, useNavigate } from "react-router-dom";

interface FinishGameScreenProps {
    socket: Socket<DefaultEventsMap, DefaultEventsMap> 
}

function FinishGameScreen({socket}:FinishGameScreenProps) {
    const[message, setMessage] = useState('Winner User Shows Up here')

  socket.on('winner', (message) => {
    console.log(message)
    setMessage(message);
  })
  return(
    <div>
    <h1>Game Over</h1>
    <h1>{message}</h1>

  </div>

  )
}

export default FinishGameScreen;
