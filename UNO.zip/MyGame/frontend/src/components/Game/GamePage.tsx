import { Socket } from "socket.io-client" 
import React, { useEffect } from 'react';
import { useState } from 'react';
import { DefaultEventsMap } from "socket.io/dist/typed-events"
import './uno.css'
import './uno-cards.css'
import UnoCard from "./CardContainer";
import { Navigate, useNavigate } from "react-router-dom";


interface CardData {
  color: string;
  value: string;
}

interface GameEventsProps {
    socket: Socket<DefaultEventsMap, DefaultEventsMap> 
}



function Game({socket}:GameEventsProps){
  const [hand, setHand] = useState<CardData[]>([
    { value: 'D4', color: 'wild' },
    { value: '2', color: 'blue' },
    { value: 'D2', color: 'red' },
    { value: 'S', color: 'red' },
    { value: '7', color: 'green' },
    { value: '7', color: 'blue' },
    { value: '7', color: 'red' }
  ]);
  const [discard, discardPile] = useState<CardData>({value: '6', color: 'red'});
  const [deck, deckTop] = useState<CardData>({value: 'D2', color: 'red'});

  const [name, yourName] = useState('');
  const [players, otherPlayers] = useState([]);
  const[message, setMessage] = useState('Lets Start with Player 1')
  const[username, setUsername] = useState('Welcome to Uno')

  const navigate = useNavigate();


  // const [turn, changeTurn] = useState(false)


  useEffect(() => {

    socket.on("turn", (message) => {
      console.log(message)
      setMessage(message);
    });

    socket.on("card-unplayable", (message) => {
      console.log(message)
      setMessage(message);
    });

    }, [message]);

    socket.on("winner", (message) => {
      console.log(message)
      setMessage(message);
      navigate('/finish')
    }); 

   socket.on('first-person', (message) => {
      console.log(message)
      setMessage(message);
    });

    socket.on("username", (message) => {
      let welcome:string = "Welcome " + message
      setUsername(welcome);
    });


    const handlePass = (socket: Socket) => {

      socket.emit('pass', (''));
      

  };

  
  useEffect(() => {
    socket.on("hand", (handData) => {
      console.log("I received the hand")
      setHand(handData);
    });

    }, [hand]);

  useEffect(() => {
    socket.on("discardPile", (handData) => {
      console.log("Display discard pile")
      discardPile(handData);
    });
  }, [discard, socket]);


  useEffect(() => {
    socket.on("deckTop", (handData) => {
      console.log("Deck top")
      deckTop(handData);
    });
  }, [deck, socket]);

    socket.on('yourName', (playerNames) => {
      console.log("Display you names")
      yourName(playerNames);
    });

    socket.on('otherPlayerNames', (otherPlayerss) => {
      console.log("Display other player names")
      otherPlayers(otherPlayerss);
    });

  const handleClick = (index:number, color:string) => {
    console.log('Clicked card: ',[index, color]);
    let arr = [index , color]
    socket.emit('play-card', (arr))  
    socket.on('valid-turn', (handData) => 
    { 
      let f = hand
      let y =   f.filter((_, i) => i !== index)
      setHand(y);
    });

  }


  // socket.on()


  return( 
    <div className="GamePage">
    <head>
    <meta charSet="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Uno</title>
    <link rel="stylesheet" href="uno.css" />
    <link rel="stylesheet" href="uno-cards.css" />
  </head>
  <body>
    <div className="main-container">
      <div className="game-container">
        <div className="heading-container">
          <h1>UNO</h1>
        </div>
        <div className="game-table-container">
          <div className="game-table">
            <div className="card-area">
              <div className={`card num-${discard.value} ${discard.color}`}>
                <span className="inner">
                  <span className="mark">{discard.value}</span>
                </span>
              </div>
              <div className={`card num-${deck.value} ${deck.color}`}>
                <span className="inner">
                  <span className="mark">{deck.value}</span>
                </span>
              </div>
            </div>
            <div className="game-players-container">
              <div className="player-tag player-one">{name}</div>
            </div>
            <div className="game-players-container">
              <div className="player-tag player-two">{players[0]}</div>
            </div>
            <div className="game-players-container">
              <div className="player-tag player-three">{players[0]}</div>
            </div>
            <div className="game-players-container">
              <div className="player-tag player-four">{players[0]}</div>
            </div>
          </div>
        </div>
        <div className="select-rang-container">
          {/* <button className="button-select-rang" onClick={() => handleDeck(socket)} >Pick from deck</button > */}
          <button className="button-select-rang"onClick={() => handlePass(socket)}>Pass</button>
        </div>
      </div>
      <div className="messages-and-cards-container">
        <div className="right-side-container messages-container">
          <h1>Messages</h1>
          <div className="message-box">
            <div className="message-content-container">
              {message}
            </div>
            <div className="message-content-container">
              {username}
            </div>
          </div>
        </div>
        <div className="right-side-container my-cards-container">
          <h1>My Cards</h1>
          <div className="my-cards-inner-container">
          {hand.map((card, index) => (
            <UnoCard
              key={index}
              color={card.color}
              value={card.value}
              onClick={() => handleClick(index, card.color)}
            />
          ))}
          </div>
        </div>
      </div>
    </div>
  </body>
    </div> 

  );
}




export default Game
