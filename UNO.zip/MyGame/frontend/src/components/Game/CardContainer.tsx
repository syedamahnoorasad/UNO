import React from "react";
import "./uno-cards.css";

type UnoCardProps = {
    key: number;
    color: string;
    value: string;
    onClick: (index:number, color:string) => void;
  };


function UnoCard ({ key, color, value, onClick }: UnoCardProps) {
    // const handleClick = () => {
    //     onClick(key);
    //   };

  return (
    <div className={`card num-${value} ${color}`} onClick={() => onClick(key, color)}>
          <span className="inner">
          <span className="mark">{value}</span>
          </span>
    </div>
  );
};

export default UnoCard;

  //             </div>
  //             <div className="card num-6 yellow">
  //               <span className="inner">
  //                 <span className="mark">6</span>
  //               </span>
  //             </div>
